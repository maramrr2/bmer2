## Teamodoro
Teamodoro is a simple pomodoro timer for teams. It helps improving the productivity of your team and reducing interruptions: http://teamodoro.com.

![Teamodoro screenshot](/images/teamodoro_screenshot.jpg)

## Other versions
- [Mac OS menubar app](https://github.com/youzi/teamodoro-mac) by [Youzi](https://github.com/youzi)

## MIT license

Made by [Base Secrète](https://basesecrete.com).

Rails developer? Check out [RoRvsWild](https://www.rorvswild.com), our Ruby on Rails application monitoring tool.
